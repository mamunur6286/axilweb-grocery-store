<?php

namespace GroceryStore\PreOrderManagement\Services;

class ExampleService
{
    public function format()
    {
        // do formatting
    }
}
