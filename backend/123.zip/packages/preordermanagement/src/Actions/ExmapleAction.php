<?php

namespace GroceryStore\PreOrderManagement\Actions;

use GroceryStore\PreOrderManagement\Events\PreOrderEmailEvent;
use GroceryStore\PreOrderManagement\Models\PreOrder;

class ExmapleAction
{
    /**
     * Summary of execute
     * @param \GroceryStore\PreOrderManagement\Models\PreOrder $preOrder
     * @return void
     */
    public function execute(PreOrder $preOrder): void
    {
    }
}