# Pre Order confirmation

Your pre-order has been placed. Below are the details:

**Order ID:** 0000<?php echo e($preOrder->id); ?>  
**Customer Name:** <?php echo e($preOrder->name); ?>  
**Email:** <?php echo e($preOrder->email); ?>  
**Total Amount:** <?php echo e($preOrder->phone); ?>  
**Total Amount:** <?php echo e($preOrder->description); ?>  


Thank you for managing the orders!

Best Regards,  
<?php echo e(config('app.name')); ?>

<?php /**PATH /home/mamun/Documents/projects/laravel-package-dev/backend/packages/preordermanagement/resources/views/mail/user_mail.blade.php ENDPATH**/ ?>